import { setToken, setRefreshToken, getToken, api, register as apiRegister, login as apiLogin, refresh as apiRefresh, logout as apiLogout } from '../api-client.js';

export const authStore = {
  user: null,
  isAuthenticated() { return !!getToken(); },
  getAccessToken() { return getToken(); },
  async getCurrentUser() {
    if (this.user) return this.user;
    return await this.loadUser();
  },
  async loadUser() {
    if (!this.isAuthenticated()) return null;
    try {
      const res = await api('/auth/me');
      this.user = res.data?.user || res.user || null;
      return this.user;
    } catch (e) {
      const refreshed = await this.refresh();
      if (refreshed) {
        try {
          const res2 = await api('/auth/me');
          this.user = res2.data?.user || res2.user || null;
          return this.user;
        } catch (err) {}
      }
      await this.logout();
      return null;
    }
  },
  async login(credentials) {
    const res = await apiLogin(credentials);
    await this.loadUser();
    return res;
  },
  async register(data) {
    const res = await apiRegister(data);
    await this.loadUser();
    return res;
  },
  async refresh() {
    try {
      return await apiRefresh();
    } catch (e) {
      return null;
    }
  },
  async logout() {
    try { await apiLogout(); } catch (e) {}
    setToken('');
    setRefreshToken('');
    this.user = null;
    if (typeof window !== 'undefined' && !window.location.pathname.includes('login.html')) {
      window.location.href = './login.html';
    }
  }
};