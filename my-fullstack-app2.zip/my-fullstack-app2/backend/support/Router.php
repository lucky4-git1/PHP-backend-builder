<?php
/** Router: GET/POST/PUT/PATCH/DELETE/OPTIONS/HEAD, {param} placeholders, 404 vs 405. */
declare(strict_types=1);

namespace App\Support;

final class Router
{
    private array $routes = [];

    public function add(string $method, string $path, callable $handler, array $middleware = []): void
    {
        $pattern = '#^' . preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', '(?P<$1>[^/]+)', $path) . '$#';
        $this->routes[] = ['method' => strtoupper($method), 'pattern' => $pattern, 'handler' => $handler, 'middleware' => $middleware, 'path' => $path];
    }

    public function group(string $prefix, callable $cb, array $middleware = []): void
    {
        $before = count($this->routes);
        $cb($this);
        for ($i = $before; $i < count($this->routes); $i++) {
            $this->routes[$i]['pattern'] = '#^' . preg_quote($prefix, '#') . substr($this->routes[$i]['pattern'], 2);
            $this->routes[$i]['middleware'] = array_merge($middleware, $this->routes[$i]['middleware']);
        }
    }

    /** @return string one of dispatched|not_found|method_not_allowed */
    public function dispatch(Request $req): string
    {
        $pathMatch = false;
        foreach ($this->routes as $r) {
            if (preg_match($r['pattern'], $req->path, $m)) {
                $pathMatch = true;
                if ($r['method'] !== $req->method) continue;
                $params = [];
                foreach ($m as $k => $v) { if (is_string($k)) $params[$k] = $v; }
                ($r['handler'])($req, $params);
                return 'dispatched';
            }
        }
        return $pathMatch ? 'method_not_allowed' : 'not_found';
    }

    public function list(): array
    {
        return array_map(fn($r) => ['method' => $r['method'], 'path' => $r['path']], $this->routes);
    }
}
