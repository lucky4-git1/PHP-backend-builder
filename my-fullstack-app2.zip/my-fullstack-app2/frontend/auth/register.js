import { register } from '../api-client.js';

const form = document.getElementById('register-form');
const errorMsg = document.getElementById('error-msg');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorMsg.style.display = 'none';
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  try {
    await register({ name, email, password });
    window.location.href = '/';
  } catch (err) {
    errorMsg.textContent = err.message || 'Registration failed';
    errorMsg.style.display = 'block';
  }
});