<?php
/**
 * Minimal HS256 JWT (no dependencies). Cryptographic token operations only.
 * Explicit algorithm verification (HS256), timing-safe signature comparison (hash_equals),
 * expiration and token structure validation. Database-independent.
 */
declare(strict_types=1);

namespace App\Support;

final class Jwt
{
    private const ALLOWED_ALGORITHMS = ['HS256'];

    public static function encode(array $payload, string $secret, int $ttlSeconds): string
    {
        $header = ['alg' => 'HS256', 'typ' => 'JWT'];
        $h = self::b64((string)json_encode($header));
        $now = time();
        $payload['iat'] = $now;
        $payload['exp'] = $now + $ttlSeconds;
        $p = self::b64((string)json_encode($payload));
        $sig = self::b64(hash_hmac('sha256', $h . '.' . $p, $secret, true));
        return $h . '.' . $p . '.' . $sig;
    }

    public static function decode(string $token, string $secret): ?array
    {
        if (trim($token) === '') return null;
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        [$h, $p, $s] = $parts;

        // 1. Header validation — reject missing / non-HS256 / algorithm confusion
        $rawHeader = self::ub64($h);
        if ($rawHeader === false) return null;
        $header = json_decode($rawHeader, true);
        if (!is_array($header)) return null;
        $alg = (string)($header['alg'] ?? '');
        if (!in_array($alg, self::ALLOWED_ALGORITHMS, true)) return null;

        // 2. Cryptographic signature check (timing-safe)
        $expected = self::b64(hash_hmac('sha256', $h . '.' . $p, $secret, true));
        if (!hash_equals($expected, $s)) return null;

        // 3. Payload validation
        $rawPayload = self::ub64($p);
        if ($rawPayload === false) return null;
        $payload = json_decode($rawPayload, true);
        if (!is_array($payload)) return null;

        // 4. Token structure & standard claim checks
        if (!isset($payload['sub']) || (string)$payload['sub'] === '') return null;
        if (!isset($payload['exp']) || !is_numeric($payload['exp']) || (int)$payload['exp'] < time()) return null;
        if (isset($payload['iat']) && is_numeric($payload['iat']) && (int)$payload['iat'] > (time() + 60)) return null;

        return $payload;
    }

    private static function b64(string $bin): string
    {
        return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }

    private static function ub64(string $s): string|false
    {
        $remainder = strlen($s) % 4;
        if ($remainder) { $s .= str_repeat('=', 4 - $remainder); }
        return base64_decode(strtr($s, '-_', '+/'), true);
    }
}
