<?php
/**
 * RequestContext — request-scoped context carrying requestId, authenticated user, and metadata.
 * Pure dependency injection, zero global mutable state.
 */
declare(strict_types=1);

namespace App\Support;

final class RequestContext
{
    public function __construct(
        public readonly string $requestId,
        public ?array $user = null,
        public array $metadata = []
    ) {}
}
