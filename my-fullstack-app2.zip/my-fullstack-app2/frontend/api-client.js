// Drop-in fetch client for blog-api — generated from the SAME IR as the backend.
// Base URL: VITE_API_URL env, else same-origin. Never hardcode production URLs.

var BASE = '';
try { if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_API_URL) BASE = import.meta.env.VITE_API_URL; } catch (e) {}
try { if (!BASE && typeof process !== 'undefined' && process.env && process.env.API_URL) BASE = process.env.API_URL; } catch (e) {}
if (!BASE) BASE = '/api/v1';
var token = '';
var refreshToken = '';
try { token = localStorage.getItem('token') || ''; refreshToken = localStorage.getItem('refresh_token') || ''; } catch (e) {}

export function setToken(t) { token = t || ''; try { localStorage.setItem('token', token); } catch (e) {} }
export function setRefreshToken(t) { refreshToken = t || ''; try { localStorage.setItem('refresh_token', refreshToken); } catch (e) {} }
export function getToken() { return token; }
function storeAuth(d) { var data = (d && d.data) || d || {}; if (data.token) setToken(data.token); if (data.refresh_token) setRefreshToken(data.refresh_token); }

export async function api(path, opts) {
  opts = opts || {};
  var method = opts.method || 'GET';
  var query = opts.query || {};
  var body = opts.body;
  var headers = opts.headers || {};
  var timeoutMs = opts.timeout || 15000;
  var qs = new URLSearchParams(query).toString();
  var h = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = 'Bearer ' + token;
  for (var k in headers) h[k] = headers[k];
  var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  var timer = ctrl ? setTimeout(function(){ try { ctrl.abort(); } catch(e){} }, timeoutMs) : null;
  try {
    var res = await fetch(BASE + path + (qs ? '?' + qs : ''), {
      method: method, headers: h,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl ? ctrl.signal : undefined,
    });
    var data = await res.json().catch(function () { return {}; });
    if (res.status === 401 && refreshToken && path !== '/auth/refresh' && !opts._retried) {
      try { var r = await api('/auth/refresh', { method: 'POST', body: { refresh_token: refreshToken }, _retried: true }); storeAuth(r); h['Authorization'] = 'Bearer ' + token; var res2 = await fetch(BASE + path + (qs ? '?' + qs : ''), { method: method, headers: h, body: body ? JSON.stringify(body) : undefined }); var data2 = await res2.json().catch(function(){ return {}; }); if (!res2.ok) throw Object.assign(new Error(((data2.error||{}).message) || ('HTTP ' + res2.status)), { status: res2.status, code: (data2.error||{}).code, data: data2 }); return data2; } catch (e) { /* refresh failed — fall through */ }
    }
    if (!res.ok) throw Object.assign(new Error(((data.error||{}).message) || ((data.data||{}).error) || ('HTTP ' + res.status)), { status: res.status, code: (data.error||{}).code, data: data });
    return data;
  } catch (e) { if (e && e.name === 'AbortError') throw Object.assign(new Error('Request timeout'), { code: 'TIMEOUT' }); throw e; }
  finally { if (timer) clearTimeout(timer); }
}

export async function register(data) { var r = await api('/auth/register', { method: 'POST', body: data }); storeAuth(r); return r; }
export async function login(data) { var r = await api('/auth/login', { method: 'POST', body: data }); storeAuth(r); return r; }
export async function refresh() { var r = await api('/auth/refresh', { method: 'POST', body: { refresh_token: refreshToken } }); storeAuth(r); return r; }
export async function me() { return api('/auth/me'); }
export async function logout() { try { await api('/auth/logout', { method: 'POST', body: { refresh_token: refreshToken } }); } catch (e) {} setToken(''); setRefreshToken(''); }

export async function listUsers(params) { return api('/users', { query: params || {} }); }
export async function getUser(id) { return api('/users/' + encodeURIComponent(id)); }
export async function createUser(data) { return api('/users', { method: 'POST', body: data }); }
export async function updateUser(id, data) { return api('/users/' + encodeURIComponent(id), { method: 'PUT', body: data }); }
export async function patchUser(id, data) { return api('/users/' + encodeURIComponent(id), { method: 'PATCH', body: data }); }
export async function deleteUser(id) { return api('/users/' + encodeURIComponent(id), { method: 'DELETE' }); }

export async function listPosts(params) { return api('/posts', { query: params || {} }); }
export async function getPost(id) { return api('/posts/' + encodeURIComponent(id)); }
export async function createPost(data) { return api('/posts', { method: 'POST', body: data }); }
export async function updatePost(id, data) { return api('/posts/' + encodeURIComponent(id), { method: 'PUT', body: data }); }
export async function patchPost(id, data) { return api('/posts/' + encodeURIComponent(id), { method: 'PATCH', body: data }); }
export async function deletePost(id) { return api('/posts/' + encodeURIComponent(id), { method: 'DELETE' }); }

export async function listComments(params) { return api('/comments', { query: params || {} }); }
export async function getComment(id) { return api('/comments/' + encodeURIComponent(id)); }
export async function createComment(data) { return api('/comments', { method: 'POST', body: data }); }
export async function updateComment(id, data) { return api('/comments/' + encodeURIComponent(id), { method: 'PUT', body: data }); }
export async function patchComment(id, data) { return api('/comments/' + encodeURIComponent(id), { method: 'PATCH', body: data }); }
export async function deleteComment(id) { return api('/comments/' + encodeURIComponent(id), { method: 'DELETE' }); }
