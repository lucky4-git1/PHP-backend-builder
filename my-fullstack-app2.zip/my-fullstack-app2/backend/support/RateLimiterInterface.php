<?php
/** RateLimiterInterface — file impl by default, Redis impl can be swapped in. */
declare(strict_types=1);

namespace App\Support;

interface RateLimiterInterface
{
    public function hit(string $key, int $perMinute): bool;
    public function remaining(string $key, int $perMinute): int;
}
