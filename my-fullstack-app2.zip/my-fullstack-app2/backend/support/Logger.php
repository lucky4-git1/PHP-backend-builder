<?php
/**
 * Structured logger — never logs passwords/JWTs/refresh tokens/keys/headers.
 * Context-aware logging without global state.
 */
declare(strict_types=1);

namespace App\Support;

final class Logger
{
    private const SECRET_KEYS = ['password', 'passwd', 'secret', 'token', 'jwt', 'refresh_token', 'authorization', 'api_key', 'apikey', 'db_pass', 'db_password'];
    public static function log(string $level, string $msg, array $ctx = [], string $requestId = '-'): void
    {
        $safe = self::redact($ctx);
        $line = json_encode(['ts' => date('c'), 'level' => $level, 'request_id' => $requestId, 'msg' => $msg, 'ctx' => $safe], JSON_UNESCAPED_SLASHES);
        error_log((string)$line);
    }
    public static function debug(string $m, array $c = [], string $rid = '-'): void { self::log('debug', $m, $c, $rid); }
    public static function info(string $m, array $c = [], string $rid = '-'): void { self::log('info', $m, $c, $rid); }
    public static function warning(string $m, array $c = [], string $rid = '-'): void { self::log('warning', $m, $c, $rid); }
    public static function error(string $m, array $c = [], string $rid = '-'): void { self::log('error', $m, $c, $rid); }
    private static function redact(array $ctx): array
    {
        $out = [];
        foreach ($ctx as $k => $v) {
            $lk = strtolower((string)$k);
            $hit = false;
            foreach (self::SECRET_KEYS as $s) { if (strpos($lk, $s) !== false) { $hit = true; break; } }
            $out[$k] = $hit ? '[redacted]' : $v;
        }
        return $out;
    }
}
