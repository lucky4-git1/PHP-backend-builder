<?php
/**
 * Global exception handler — prod hides SQL/paths/traces; dev may show diagnostics.
 * Zero global mutable state.
 */
declare(strict_types=1);

namespace App\Support;

use Throwable;

final class Handler
{
    public static function register(array $config): void
    {
        set_exception_handler(function (Throwable $e) use ($config) {
            $debug = ($config['env'] ?? 'production') !== 'production';
            Logger::error('unhandled', ['class' => get_class($e), 'message' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine()]);
            if ($debug) {
                Response::error('INTERNAL', $e->getMessage(), 500, ['file' => basename($e->getFile()), 'line' => $e->getLine()]);
            } else {
                Response::error('INTERNAL', 'An internal server error occurred.', 500);
            }
        });
    }
}
