<?php
/** Minimal .env loader — real env vars always win; .env never logged. */
declare(strict_types=1);

namespace App\Support;

final class Env
{
    public static function load(string $dir): void
    {
        $file = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . '.env';
        if (!is_file($file) || !is_readable($file)) return;
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') continue;
            $pos = strpos($line, '=');
            if ($pos === false) continue;
            $k = trim(substr($line, 0, $pos));
            $v = trim(substr($line, $pos + 1));
            if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $k)) continue;
            if (strlen($v) >= 2 && (($v[0] === '"' && substr($v, -1) === '"') || ($v[0] === "'" && substr($v, -1) === "'"))) { $v = substr($v, 1, -1); }
            if (getenv($k) === false && !isset($_SERVER[$k]) && !isset($_ENV[$k])) {
                putenv($k . '=' . $v);
                $_ENV[$k] = $v;
                $_SERVER[$k] = $v;
            }
        }
    }
}
