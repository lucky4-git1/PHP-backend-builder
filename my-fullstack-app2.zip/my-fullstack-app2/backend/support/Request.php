<?php
/** HTTP request helper with RequestContext. */
declare(strict_types=1);

namespace App\Support;

final class Request
{
    public string $method;
    public string $path;
    public array $query;
    public array $headers;
    private ?array $parsedBody = null;
    public ?array $user = null;
    public RequestContext $context;

    public function __construct(?RequestContext $context = null)
    {
        $this->context = $context ?? new RequestContext(RequestId::handle());
        $this->method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $this->path = $uri === '' ? '/' : $uri;
        $this->query = $_GET ?? [];
        $this->headers = $this->readHeaders();
    }

    public function context(): RequestContext
    {
        return $this->context;
    }

    private function readHeaders(): array
    {
        $out = [];
        foreach ($_SERVER as $k => $v) {
            if (substr($k, 0, 5) === 'HTTP_') {
                $name = strtolower(str_replace('_', '-', substr($k, 5)));
                $out[$name] = (string)$v;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) $out['content-type'] = (string)$_SERVER['CONTENT_TYPE'];
        return $out;
    }

    public function query(string $key, string $default = ''): string
    {
        $v = $this->query[$key] ?? $default;
        return is_string($v) ? $v : $default;
    }

    public function body(): array
    {
        if ($this->parsedBody !== null) return $this->parsedBody;
        $raw = file_get_contents('php://input') ?: '';
        if ($raw === '') { $this->parsedBody = $_POST ?? []; return $this->parsedBody; }
        $ct = $this->headers['content-type'] ?? '';
        if (strpos($ct, 'application/json') !== false) {
            $d = json_decode($raw, true);
            $this->parsedBody = is_array($d) ? $d : [];
        } else {
            parse_str($raw, $d);
            $this->parsedBody = is_array($d) ? array_merge($_POST ?? [], $d) : ($_POST ?? []);
        }
        return $this->parsedBody;
    }

    public function bearer(): ?string
    {
        $h = $this->headers['authorization'] ?? '';
        if (substr($h, 0, 7) === 'Bearer ') return substr($h, 7);
        return null;
    }
}
