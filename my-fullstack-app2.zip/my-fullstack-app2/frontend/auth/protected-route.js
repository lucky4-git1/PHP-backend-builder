import { authStore } from './auth-store.js';

export async function requireAuth(roles = []) {
  if (typeof window === 'undefined') return false;
  const currentPath = window.location.pathname + window.location.search;
  if (window.location.pathname.endsWith('login.html') || window.location.pathname.endsWith('register.html')) {
    return true;
  }
  if (!authStore.isAuthenticated()) {
    window.location.href = './login.html?redirect=' + encodeURIComponent(currentPath);
    return false;
  }
  let user = await authStore.getCurrentUser();
  if (!user) {
    const refreshed = await authStore.refresh();
    if (refreshed) user = await authStore.getCurrentUser();
  }
  if (!user) {
    window.location.href = './login.html?redirect=' + encodeURIComponent(currentPath);
    return false;
  }
  if (roles.length > 0 && !roles.includes(user.role)) {
    alert('Access denied: insufficient permissions');
    window.location.href = '../index.html';
    return false;
  }
  return true;
}