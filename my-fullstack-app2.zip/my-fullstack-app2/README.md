# blog-api

Generated with **PHP Backend Builder** v2.0.0 (IR v1.0.0) — PHP 8.2 + PDO + MySQL.

## Quick start

```bash
composer install
cp .env.example .env
php bin/backend key:generate   # crypto-secure JWT_SECRET -> .env (never committed)
php bin/backend doctor         # PHP/ext/env/DB/JWT/migration checks
mysql -u root -p -e "CREATE DATABASE blog_api CHARACTER SET utf8mb4;"
php database/migrate.php migrate   # tracked via migrations table
php database/migrate.php migrate:status
php bin/backend serve            # or: php -S localhost:8000 -t backend/public
```

## Auth

```bash
curl -X POST http://localhost:8000/api/v1/auth/register -H 'Content-Type: application/json' -d '{"name":"Ada","email":"ada@example.com","password":"secret123"}'
curl http://localhost:8000/api/v1/health/live
curl http://localhost:8000/api/v1/health/ready
```
Routes: POST /auth/register, POST /auth/login, POST /auth/logout, POST /auth/refresh, GET /auth/me.
Refresh tokens rotate on every use; only SHA-256 hashes are stored; reuse is rejected.

## Layout

- backend/public/index.php — front controller (RequestId, Handler, security headers, CORS, rate limit, auth guard, 404/405)
- backend/controllers/ — thin CRUD (validation rules from IR, PATCH=partial, password logic ONLY in users/Auth)
- backend/models/ — fillable/hidden/casts from canonical IR (password always hidden)
- backend/support/ — Container (PSR-11), Request, Response (envelope), Router (404/405), Middleware, RateLimiterInterface, Logger (redacted), Handler, Jwt, RequestId
- database/ — schema.sql + ordered migrations + migrate.php (migrate|rollback|status|fresh)
- bin/backend — doctor|key:generate|routes|serve
- frontend/api-client.js — IR-generated client (timeout, refresh, request-id, no hardcoded URL)
- docs/openapi.json — generated from SAME IR (schemas per resource)
- tests/ApiTest.php — health/auth/CRUD/validation/pagination (phpunit)
- composer.json / phpunit.xml — PSR-4, PHPUnit, PHPStan

## Deployment

- Web root MUST be `backend/public/` (Apache/Nginx/PHP-FPM).
- `docker-compose up --build` for optional Docker (not required locally).
- Production: APP_ENV=production, APP_DEBUG=false, CORS_ORIGINS=https://your-frontend, HTTPS + HSTS.

## Security notes

- All SQL uses bound parameters; sort/filter columns allow-listed; max page size enforced.
- Passwords: password_hash/password_verify, never serialized, never logged.
- JWT: minimal claims (sub/jti/iat/exp), hash_equals verify, empty default + key:generate.
- Rate limiting with file locking (auth stricter, 429 + Retry-After); CORS never wildcard+credentials.
- Errors: standardized {success,error{code,message,details},request_id}; prod hides SQL/paths/traces.
