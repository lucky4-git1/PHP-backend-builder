<?php
/** CORS (configurable, no wildcard+credentials) + secure headers + rate limit with locking. */
declare(strict_types=1);

namespace App\Support;

final class Middleware
{
    public static function cors(string $origins, bool $credentials = false): void
    {
        $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
        $allow = '*';
        if ($origins !== '*' && $origin !== '') {
            $list = array_map('trim', explode(',', $origins));
            $allow = in_array($origin, $list, true) ? $origin : $list[0];
            header('Vary: Origin');
        } else {
            header('Vary: Origin');
        }
        if ($origins === '*' && $credentials) { $allow = $origin !== '' ? $origin : 'null'; }
        header('Access-Control-Allow-Origin: ' . $allow);
        header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-Request-ID');
        if ($credentials) header('Access-Control-Allow-Credentials: true');
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }
    }

    public static function securityHeaders(): void
    {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        if ((($_SERVER['HTTPS'] ?? '') !== '') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
    }

    public static function rateLimit(int $perMinute = 120, ?string $key = null): void
    {
        $dir = sys_get_temp_dir() . '/phpbb_rl';
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        $id = $key ?? (string)($_SERVER['REMOTE_ADDR'] ?? 'cli');
        $safe = preg_replace('/[^a-zA-Z0-9.:_-]/', '_', $id);
        $file = $dir . '/' . $safe . '.json';
        $fp = fopen($file, 'c+');
        if ($fp === false) return;
        flock($fp, LOCK_EX);
        $now = time();
        $bucket = ['t' => $now, 'n' => 0];
        $raw = stream_get_contents($fp);
        if ($raw) {
            $d = json_decode($raw, true);
            if (is_array($d) && isset($d['t'], $d['n'])) $bucket = $d;
        }
        if ($now - (int)$bucket['t'] >= 60) { $bucket = ['t' => $now, 'n' => 0]; }
        $bucket['n']++;
        ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($bucket)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
        header('X-RateLimit-Limit: ' . $perMinute);
        header('X-RateLimit-Remaining: ' . max(0, $perMinute - (int)$bucket['n']));
        if ($bucket['n'] > $perMinute) {
            header('Retry-After: ' . max(1, 60 - ($now - (int)$bucket['t'])));
            Response::error('RATE_LIMITED', 'Too many requests', 429);
            exit;
        }
    }

    public static function authRateLimit(): void
    {
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'cli');
        self::rateLimit(20, 'auth_' . $ip);
    }
}
