<?php
/**
 * Standardized JSON envelope: {success,data,meta,request_id} / {success:false,error{code,message,details},request_id}.
 * Zero global state — receives request ID cleanly from RequestContext.
 */
declare(strict_types=1);

namespace App\Support;

final class Response
{
    public static function json($data, int $status = 200, string $requestId = ''): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        if ($requestId !== '') header('X-Request-ID: ' . $requestId);
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    public static function ok($data, array $meta = [], string $requestId = ''): void
    {
        $body = ['success' => true, 'data' => $data];
        if ($meta) $body['meta'] = $meta;
        if ($requestId !== '') $body['request_id'] = $requestId;
        self::json($body, 200, $requestId);
    }

    public static function collection(array $rows, int $page, int $perPage, int $total, string $requestId = ''): void
    {
        $last = (int)ceil($total / max(1, $perPage));
        $body = ['success' => true, 'data' => $rows, 'meta' => ['current_page' => $page, 'per_page' => $perPage, 'total' => $total, 'last_page' => $last]];
        if ($requestId !== '') $body['request_id'] = $requestId;
        self::json($body, 200, $requestId);
    }

    public static function error(string $code, string $message, int $status = 400, array $details = [], string $requestId = ''): void
    {
        $body = ['success' => false, 'error' => ['code' => $code, 'message' => $message, 'details' => $details]];
        if ($requestId !== '') $body['request_id'] = $requestId;
        self::json($body, $status, $requestId);
    }
}
