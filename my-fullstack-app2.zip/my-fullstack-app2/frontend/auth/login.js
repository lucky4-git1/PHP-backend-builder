import { login } from '../api-client.js';

const form = document.getElementById('login-form');
const errorMsg = document.getElementById('error-msg');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorMsg.style.display = 'none';
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  try {
    await login({ email, password });
    const params = new URLSearchParams(window.location.search);
    window.location.href = params.get('redirect') || '/';
  } catch (err) {
    errorMsg.textContent = err.message || 'Login failed';
    errorMsg.style.display = 'block';
  }
});